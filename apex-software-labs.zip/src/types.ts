export interface ChatMessage {
  role: "user" | "model";
  text: string;
}

export interface DatabaseChoice {
  recommended: string;
  justification: string;
}

export interface SystemComponent {
  component: string;
  technology: string;
  role: string;
}

export interface ArchitectureBlueprint {
  introduction: string;
  diagramText: string;
  databaseChoice: DatabaseChoice;
  cachingLayer: string;
  scalingStratey: string;
  componentsTable: SystemComponent[];
  riskAnalysis: string[];
}

export interface HashNode {
  id: string;
  name: string;
  hash: number; // 0 to 359 (degrees on the ring)
  color: string;
}

export interface HashKey {
  id: string;
  originalKey: string;
  hash: number; // 0 to 359
  assignedNodeId: string;
}
