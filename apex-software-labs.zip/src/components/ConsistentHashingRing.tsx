import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HashNode, HashKey } from "../types";
import { Network, Plus, Trash2, HelpCircle, HardDrive, Hash, ShieldCheck, Zap } from "lucide-react";

// Robust hashing helper for alphanumeric strings (mapping to 0 - 359 degrees)
function stringToHashAngle(str: string): number {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 33) ^ str.charCodeAt(i);
  }
  return Math.abs(hash) % 360;
}

export default function ConsistentHashingRing() {
  const defaultNodes: HashNode[] = [
    { id: "1", name: "Node-Alpha (SF)", hash: 45, color: "#22d3ee" }, // Cyan
    { id: "2", name: "Node-Beta (AMS)", hash: 165, color: "#3b82f6" }, // Blue
    { id: "3", name: "Node-Gamma (TKY)", hash: 280, color: "#6366f1" }, // Indigo
  ];

  const defaultKeys: HashKey[] = [
    { id: "k1", originalKey: "client_session_802", hash: 15, assignedNodeId: "1" },
    { id: "k2", originalKey: "asset_header_logo", hash: 110, assignedNodeId: "2" },
    { id: "k3", originalKey: "db_cache_query_items", hash: 190, assignedNodeId: "3" },
    { id: "k4", originalKey: "user_avatar_url_99", hash: 320, assignedNodeId: "1" },
  ];

  const nodeColors = ["#22d3ee", "#3b82f6", "#6366f1", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6"];

  const [nodes, setNodes] = useState<HashNode[]>(defaultNodes);
  const [keys, setKeys] = useState<HashKey[]>(defaultKeys);
  const [newNodeName, setNewNodeName] = useState("");
  const [newKeyName, setNewKeyName] = useState("");
  const [showExplanation, setShowExplanation] = useState(false);

  // Re-map keys clockwise to nodes when topology or keys change
  const computedAssignments = useMemo(() => {
    if (nodes.length === 0) {
      return keys.map((k) => ({ ...k, assignedNodeId: "NONE" }));
    }

    // Sort nodes on ring clockwise
    const sortedNodes = [...nodes].sort((a, b) => a.hash - b.hash);

    return keys.map((k) => {
      // Find first node index with hash >= key's hash
      let assigned = sortedNodes.find((n) => n.hash >= k.hash);
      // If none found clockwise, wrap around to first node in the sorted chain (0 deg)
      if (!assigned) {
        assigned = sortedNodes[0];
      }
      return {
        ...k,
        assignedNodeId: assigned.id,
      };
    });
  }, [nodes, keys]);

  const handleAddNode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNodeName.trim()) return;

    const angle = stringToHashAngle(newNodeName);
    const id = Date.now().toString();
    const color = nodeColors[nodes.length % nodeColors.length];
    
    // Check collision, shift slightly if identical
    let safeAngle = angle;
    while (nodes.some((n) => n.hash === safeAngle)) {
      safeAngle = (safeAngle + 13) % 360;
    }

    const newNode: HashNode = {
      id,
      name: newNodeName.trim(),
      hash: safeAngle,
      color,
    };

    setNodes([...nodes, newNode]);
    setNewNodeName("");
  };

  const handleAddKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) return;

    const angle = stringToHashAngle(newKeyName);
    const id = "key_" + Date.now().toString();

    const newKeyEntry: HashKey = {
      id,
      originalKey: newKeyName.trim(),
      hash: angle,
      assignedNodeId: "", // Will be assigned by raw computedAssignments hook
    };

    setKeys([...keys, newKeyEntry]);
    setNewKeyName("");
  };

  const handleRemoveNode = (id: string) => {
    setNodes(nodes.filter((n) => n.id !== id));
  };

  const handleRemoveKey = (id: string) => {
    setKeys(keys.filter((k) => k.id !== id));
  };

  // Convert angular position (0-359) to SVG coordinate space
  // SVG size is 300x300. Center is (150, 150). Radius is 110.
  const getCoordinates = (angle: number, radius = 100) => {
    // 0 degrees corresponds to (150 + R, 150). Standard trigonometric conversion
    const radians = (angle * Math.PI) / 180;
    const x = 150 + radius * Math.cos(radians);
    const y = 150 + radius * Math.sin(radians);
    return { x, y };
  };

  return (
    <div id="algorithm-playground" className="py-20 bg-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400">
              <Network className="w-3.5 h-3.5" /> Core Algorithmic Playground
            </div>
            <h2 className="text-3xl md:text-4xl font-sans font-medium text-white tracking-tight">
              Consistent Hashing Ring Simulator
            </h2>
            <p className="text-slate-400 max-w-xl text-sm leading-relaxed">
              Consistently distribute keys among cache nodes. In standard hashing (modulo N), adding or removing servers invalidates ~99% of data caches. Consistent Hashing limits cache miss rates strictly to <span className="text-cyan-400 font-mono">1/N</span>.
            </p>
          </div>

          <button
            onClick={() => setShowExplanation(!showExplanation)}
            className="self-start md:self-auto px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-cyan-400 hover:text-white rounded flex items-center gap-2 cursor-pointer transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
            {showExplanation ? "Hide Explanation" : "Explain Theory"}
          </button>
        </div>

        {/* Explain Card */}
        <AnimatePresence>
          {showExplanation && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-slate-900/40 p-6 rounded-xl border border-slate-800/80 space-y-4 text-xs md:text-sm text-slate-300 leading-relaxed font-sans">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2 bg-slate-950 p-4 rounded-lg border border-slate-900">
                    <span className="font-mono text-cyan-400 font-semibold text-xs block uppercase">1. Circular Topology Ring</span>
                    <p className="text-slate-400 text-xs">
                      We project both physical Server Nodes and data Cache Keys onto a unified, circular ring map of 360 virtual tokens utilizing string-based hashing algorithms.
                    </p>
                  </div>
                  <div className="space-y-2 bg-slate-950 p-4 rounded-lg border border-slate-900">
                    <span className="font-mono text-blue-400 font-semibold text-xs block uppercase">2. Clockwise Allocation</span>
                    <p className="text-slate-400 text-xs">
                      To locate where a key belongs, find its angle point on the ring, then march clockwise along the circle until reaching the first physical Server Node.
                    </p>
                  </div>
                  <div className="space-y-2 bg-slate-950 p-4 rounded-lg border border-slate-900">
                    <span className="font-mono text-indigo-400 font-semibold text-xs block uppercase">3. Elastic Resilience</span>
                    <p className="text-slate-400 text-xs">
                      If a node goes offline, only keys assigned directly to that specific node fall clockwise into the boundary of its neighbor. The remaining system nodes mapping stay completely untouched!
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Simulator Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Ring Area (visualizer on Left) */}
          <div className="lg:col-span-4 bg-slate-900 rounded-xl border border-slate-800 p-6 flex flex-col items-center justify-center space-y-6">
            <span className="text-xs font-mono text-slate-500 uppercase self-start tracking-wider">
              Visualization Grid Model
            </span>

            {/* Circle SVG */}
            <div className="relative w-[300px] h-[300px] flex items-center justify-center bg-black/40 rounded-full border border-slate-850 p-4 shadow-inner">
              
              <svg className="absolute inset-0 w-full h-full select-none" viewBox="0 0 300 300">
                {/* Main hashing ring track */}
                <circle
                  cx="150"
                  cy="150"
                  r="100"
                  fill="none"
                  stroke="#1e293b"
                  strokeWidth="3"
                  className="stroke-slate-800"
                />
                <circle
                  cx="150"
                  cy="150"
                  r="100"
                  fill="none"
                  stroke="rgba(6, 182, 212, 0.05)"
                  strokeWidth="10"
                />

                {/* Draw mapping chord lines between key and node */}
                {computedAssignments.map((k) => {
                  const nodeObj = nodes.find((n) => n.id === k.assignedNodeId);
                  if (!nodeObj) return null;
                  const ptKey = getCoordinates(k.hash, 88); 
                  const ptNode = getCoordinates(nodeObj.hash, 98);
                  return (
                    <line
                      key={`chord-${k.id}`}
                      x1={ptKey.x}
                      y1={ptKey.y}
                      x2={ptNode.x}
                      y2={ptNode.y}
                      stroke={nodeObj.color}
                      strokeWidth="1.5"
                      strokeDasharray="3 3"
                      className="opacity-50"
                    />
                  );
                })}

                {/* Draw angular tick marks */}
                {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => {
                  const ptStart = getCoordinates(deg, 96);
                  const ptEnd = getCoordinates(deg, 104);
                  return (
                    <line
                      key={`tick-${deg}`}
                      x1={ptStart.x}
                      y1={ptStart.y}
                      x2={ptEnd.x}
                      y2={ptEnd.y}
                      stroke="#475569"
                      strokeWidth="1"
                    />
                  );
                })}

                {/* Draw Node nodes as glowing dots */}
                {nodes.map((n) => {
                  const pt = getCoordinates(n.hash, 100);
                  return (
                    <circle
                      key={`node-pt-${n.id}`}
                      cx={pt.x}
                      cy={pt.y}
                      r="7.5"
                      fill={n.color}
                      stroke="#020617"
                      strokeWidth="1.5"
                      className="cursor-pointer hover:r-[10px] transition-all"
                    />
                  );
                })}

                {/* Draw Data Cache Keys as smaller diamond markers */}
                {computedAssignments.map((k) => {
                  const pt = getCoordinates(k.hash, 88);
                  const nodeObj = nodes.find((n) => n.id === k.assignedNodeId);
                  return (
                    <circle
                      key={`key-pt-${k.id}`}
                      cx={pt.x}
                      cy={pt.y}
                      r="4.5"
                      fill={nodeObj ? nodeObj.color : "#64748b"}
                      stroke="#020617"
                      strokeWidth="1"
                      className="cursor-pointer"
                    />
                  );
                })}
              </svg>

              {/* Angle scale markers overlay */}
              <div className="absolute top-1 flex flex-col items-center">
                <span className="text-[9px] font-mono text-slate-600">0° / H=0</span>
              </div>
              <div className="absolute right-1 self-center">
                <span className="text-[9px] font-mono text-slate-600">90°</span>
              </div>
              <div className="absolute bottom-1 flex flex-col items-center">
                <span className="text-[9px] font-mono text-slate-600">180°</span>
              </div>
              <div className="absolute left-1 self-center">
                <span className="text-[9px] font-mono text-slate-600">270°</span>
              </div>

              {/* Core statistic inside circle */}
              <div className="absolute flex flex-col items-center pointer-events-none text-center select-none bg-slate-950/80 p-3 rounded-full border border-slate-900 w-32 h-32 justify-center">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Nodes Connected</span>
                <span className="text-3xl font-mono text-white font-bold">{nodes.length}</span>
                <span className="text-[10px] font-mono text-cyan-400">Keys: {keys.length}</span>
              </div>
            </div>

            <div className="flex gap-4 text-[10px] font-mono text-slate-400 justify-center">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full border border-slate-950 bg-cyan-400 inline-block"></span> Servers</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded bg-slate-400 inline-block"></span> Data Keys</span>
            </div>
          </div>

          {/* Interactive Controller Controls (Right side - 8cols) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Split controls for Server Node insertion & Key insertion */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Insert Cache Node form */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 space-y-4">
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5 uppercase tracking-wide">
                  <Plus className="w-4 h-4 text-cyan-400" /> Scale Ring: Add Server
                </span>
                <form onSubmit={handleAddNode} className="flex gap-2">
                  <input
                    type="text"
                    value={newNodeName}
                    onChange={(e) => setNewNodeName(e.target.value)}
                    placeholder="e.g. Node-Dublin-4"
                    className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs focus:outline-none focus:border-cyan-500 font-sans"
                    maxLength={20}
                  />
                  <button
                    type="submit"
                    className="px-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded font-sans text-xs font-medium cursor-pointer transition-colors flex items-center gap-1 shrink-0"
                  >
                    Add Node
                  </button>
                </form>
                <p className="text-[10px] text-slate-500 font-sans">
                  System hashes name deterministically to find target position angle on the ring.
                </p>
              </div>

              {/* Insert Key / Item form */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 space-y-4">
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5 uppercase tracking-wide">
                  <Hash className="w-4 h-4 text-indigo-400" /> Map Cache Key (Data)
                </span>
                <form onSubmit={handleAddKey} className="flex gap-2">
                  <input
                    type="text"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                    placeholder="e.g. user_session_token_991"
                    className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs focus:outline-none focus:border-indigo-500 font-sans"
                    maxLength={30}
                  />
                  <button
                    type="submit"
                    className="px-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded font-sans text-xs font-medium cursor-pointer transition-colors shrink-0"
                  >
                    Map Key
                  </button>
                </form>
                <p className="text-[10px] text-slate-500 font-sans">
                  The data router maps this key to the closest node situatedclockwise on the hashing ring.
                </p>
              </div>

            </div>

            {/* List and State Ledger of Servers */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
              <div className="p-4 bg-slate-900/60 border-b border-slate-850 flex justify-between items-center text-xs font-mono font-semibold uppercase text-slate-300">
                <span>Core Distributed Server Nodes list</span>
                <span className="text-slate-500 text-[10px]">TOTAL: {nodes.length}</span>
              </div>
              {nodes.length === 0 ? (
                <div className="p-8 text-center text-xs font-sans text-amber-500">
                  ⚠️ Critical Warning: 0 active servers. Cloud storage router is disconnected. Add nodes.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 p-4">
                  {nodes.map((n) => {
                    const assignedKeys = computedAssignments.filter((k) => k.assignedNodeId === n.id);
                    return (
                      <div
                        key={n.id}
                        className="bg-slate-950 p-3 rounded-lg border border-slate-900 flex flex-col justify-between space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full inline-block shrink-0"
                              style={{ backgroundColor: n.color }}
                            />
                            <span className="font-mono text-xs font-semibold text-slate-200 block truncate max-w-[120px]">
                              {n.name}
                            </span>
                          </div>
                          <button
                            onClick={() => handleRemoveNode(n.id)}
                            className="text-slate-500 hover:text-red-400 cursor-pointer p-0.5"
                            title="Simulate Server Failover (Go Offline)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="text-slate-500">Ring Token: {n.hash}°</span>
                          <span className="p-0.5 px-1.5 bg-slate-900 border border-slate-800 text-cyan-400 rounded">
                            {assignedKeys.length} items cached
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* List and State Ledger of Keys */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
              <div className="p-4 bg-slate-900/60 border-b border-slate-850 flex justify-between items-center text-xs font-mono font-semibold uppercase text-slate-300">
                <span>Active Routing Table (Key assignment ledger)</span>
                <span className="text-slate-500 text-[10px]">SIMULATED RECORDS: {keys.length}</span>
              </div>
              <div className="max-h-[220px] overflow-y-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 text-[10px] font-mono border-b border-slate-900/40">
                      <th className="p-3">Data Cache Identifier</th>
                      <th className="p-3">Ring Hash</th>
                      <th className="p-3">Dynamic Clockwise Assignment</th>
                      <th className="p-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900">
                    {computedAssignments.map((k) => {
                      const associatedNode = nodes.find((n) => n.id === k.assignedNodeId);
                      return (
                        <tr key={k.id} className="hover:bg-slate-900/20 text-slate-300">
                          <td className="p-3 font-mono text-[11px] text-slate-300">{k.originalKey}</td>
                          <td className="p-3 font-mono text-xs text-slate-400">{k.hash}°</td>
                          <td className="p-3">
                            {associatedNode ? (
                              <div className="inline-flex items-center gap-1.5">
                                <span
                                  className="w-2.5 h-2.5 rounded-full inline-block"
                                  style={{ backgroundColor: associatedNode.color }}
                                />
                                <span className="text-xs font-mono font-medium text-slate-200">
                                  {associatedNode.name}
                                </span>
                              </div>
                            ) : (
                              <span className="text-xs text-red-500 bg-red-500/10 inline-block px-1.5 py-0.5 rounded border border-red-500/10">
                                ORPHANED (No Servers)
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => handleRemoveKey(k.id)}
                              className="text-slate-500 hover:text-slate-300 cursor-pointer p-1"
                              title="Delete Cache Record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
