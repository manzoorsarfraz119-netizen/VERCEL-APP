import { Cpu, HardDrive, ShieldCheck, Database, Binary, AlignLeft, Paintbrush, Award, Server } from "lucide-react";

export default function CorporateDetails() {
  const coreServices = [
    {
      category: "Computer Science (CS) Research & Labs",
      icon: <Binary className="w-6 h-6 text-cyan-400" />,
      tagline: "Theoretical Logic & Complexity Reductions",
      desc: "Our computer science practice operates at the physical limits of hardware and runtime memory constraints. We construct robust algorithmic architectures and perform formal mathematical analysis on concurrency states.",
      solutions: [
        {
          title: "Mathematical Optimization & Big-O Audits",
          detail: "Auditing application kernels to reduce logarithmic scale boundaries. We replace O(N^2) search pipelines with custom trie indexes and high-speed in-memory bitmaps."
        },
        {
          title: "Distributed Consensus Design",
          detail: "Drafting state machine replication profiles using proof-of-work, raft consensus layers, or active-active global synchronization across multiple clouds."
        },
        {
          title: "Formal TLA+ Verification",
          detail: "We model and verify complex, high-concurrency loops and distributed locking protocols mathematically before committing any production code."
        }
      ],
      exampleProject: "Consistent Hashing Ring router mapping static file cache addresses dynamically with 1/N cache drift."
    },
    {
      category: "Software Engineering (SE) Architecture",
      icon: <Cpu className="w-6 h-6 text-blue-400" />,
      tagline: "High-Load Infrastructure & Scalable Systems",
      desc: "We translate theoretical computer science bounds into strict, compile-time type-safe, multi-region container deployments running under massive transactional loads.",
      solutions: [
        {
          title: "Distributed ledgers & Database Sharding",
          detail: "Designing fault-tolerant, raft-replicated transactional ledger architectures using CockroachDB, ScyllaDB, or Cassandra for sequential writes."
        },
        {
          title: "High-Throughput Stream Ingestion",
          detail: "Constructing append-only event-driven pipelines using Apache Kafka, RabbitMQ, and gRPC queues to safely handle telemetry points."
        },
        {
          title: "Elastic Microservice Grid Meshes",
          detail: "Structuring self-healing Go/Rust container fleets mapped inside high-speed Kubernetes orchestrations with deep telemetry monitoring."
        }
      ],
      exampleProject: "Double-entry financial accounting ledger processing over 50k transactions/sec with real-time replication bound checks."
    },
    {
      category: "Systems Aesthetics & UX/UI Design",
      icon: <Paintbrush className="w-6 h-6 text-indigo-400" />,
      tagline: "User-Centered Interfaces for Complex Topologies",
      desc: "We solve cognitive overload. We craft beautiful, high-contrast, responsive human-computer interfaces designed specifically to make complex systems readable.",
      solutions: [
        {
          title: "Aesthetic Information Dashboards",
          detail: "Structuring clear typography, unified grid matrices, and dark cosmic panels designed specifically for deep diagnostic and analytics views."
        },
        {
          title: "Interactive Data Visualizations",
          detail: "Converting heavy streaming logs into lightweight vector canvases, circular hash indicators, and responsive charts using React and SVG."
        },
        {
          title: "Developer Consoles & Tool Layouts",
          detail: "Fusing configuration inputs and technical telemetry outputs into seamless split workspaces, reducing system operator fatigue."
        }
      ],
      exampleProject: "Interactive dynamic radial map node overlays transforming complex convolutional ML response weights into clear visual grids."
    }
  ];

  return (
    <div className="py-24 bg-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100 relative">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Header Block */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400 uppercase tracking-widest leading-none">
            <Award className="w-4 h-4" /> Core Capability Syllabus
          </div>
          <h2 className="text-3xl sm:text-4xl font-sans font-medium text-white tracking-tight leading-tight">
            Detailed Service Capabilities & Solutions
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Apex Software Labs operates at the exact synthesis of three disciplines. 
            We map academic computer science, construct performant software engineering channels, 
            and design intuitive visual interfaces.
          </p>
        </div>

        {/* Detailed Capability Sections (Stack visual vertical panels) */}
        <div className="space-y-12">
          {coreServices.map((service, idx) => (
            <div
              key={idx}
              className="bg-slate-900 rounded-2xl border border-slate-850 p-6 sm:p-8 flex flex-col lg:flex-row gap-8 hover:border-slate-800 hover:bg-slate-900/80 transition-all shadow-md group"
            >
              {/* Left Domain Summary Information Panel (1/3 width) */}
              <div className="lg:w-1/3 space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl inline-block">
                    {service.icon}
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest block font-bold">
                    DOMAIN MODULE 0{idx + 1}
                  </span>
                  <h3 className="text-xl font-sans font-bold text-slate-100 group-hover:text-cyan-400 transition-colors tracking-tight">
                    {service.category}
                  </h3>
                  <p className="text-slate-500 font-mono text-[11px] leading-relaxed">
                    → {service.tagline}
                  </p>
                  <p className="text-slate-400 text-xs sm:text-sm leading-relaxed font-sans">
                    {service.desc}
                  </p>
                </div>

                {/* Specific Real-world Project Example highlight */}
                <div className="pt-4 border-t border-slate-950 mt-4">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-semibold mb-1">
                    Direct Solution Example:
                  </span>
                  <span className="text-xs text-slate-300 font-sans italic bg-slate-950 p-2.5 rounded border border-slate-850 block">
                    ⚡ {service.exampleProject}
                  </span>
                </div>
              </div>

              {/* Right Detailed specific list (2/3 width) */}
              <div className="lg:w-2/3 grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
                {service.solutions.map((sol, index) => (
                  <div
                    key={index}
                    className="bg-slate-950 p-4 rounded-xl border border-slate-900 flex flex-col justify-between hover:border-slate-800 transition-all hover:bg-black/40"
                  >
                    <div className="space-y-2">
                      <span className="text-[10px] font-mono text-slate-500 font-bold tracking-wider">
                        SEC 0{idx+1}.0{index+1}
                      </span>
                      <h4 className="text-sm font-sans font-semibold text-white tracking-wide">
                        {sol.title}
                      </h4>
                      <p className="text-slate-400 text-xs leading-relaxed font-sans">
                        {sol.detail}
                      </p>
                    </div>

                    <div className="pt-6 flex items-center gap-1.5 text-emerald-400 text-[10px] font-mono">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>STANDS_UNDER_TEST</span>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          ))}
        </div>

        {/* Global operations stat section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6 text-center border-t border-slate-900/60 font-mono">
          <div className="space-y-1">
            <span className="text-xs text-slate-500 block uppercase">Algorithmic SLO</span>
            <span className="text-2xl font-bold text-cyan-400">Sub-10ms</span>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-500 block uppercase">Test Coverage</span>
            <span className="text-2xl font-bold text-blue-400">98.4% Unit</span>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-500 block uppercase">Formal Checkers</span>
            <span className="text-2xl font-bold text-indigo-400">TLA+ Verified</span>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-slate-500 block uppercase">System Availability</span>
            <span className="text-2xl font-bold text-emerald-400">99.999%</span>
          </div>
        </div>

      </div>
    </div>
  );
}
