import { Eye, Palette, Zap, Compass, RefreshCw, Feather } from "lucide-react";

export default function DesignPhilosophy() {
  const principles = [
    {
      icon: <Compass className="w-5 h-5 text-cyan-400" />,
      title: "User-Centered Design for Complex Systems",
      desc: "Deep technical tools don't have to be cryptic. We put human cognition at the center of every architectural tool. By transforming heavy distributed logs into interactive radial states and graphical rings, we reduce cognitive load and enhance developer intuition.",
    },
    {
      icon: <Feather className="w-5 h-5 text-blue-400" />,
      title: "Functional Aesthetics & High Fidelity",
      desc: "We believe visual appeal and absolute precision are mathematically aligned. Grid density, typography pairs, and dark cosmic canvas structures are not mere decorations — they are spatial layouts designed to maximize visual rhythm, balance, and information clarity.",
    },
    {
      icon: <Zap className="w-5 h-5 text-indigo-400" />,
      title: "Systems Innovation as a Standard",
      desc: "We push the envelope of client-and-server architecture. Through our in-house systems, we empower developers to prompt custom cloud schemas compiled instantly by generative modeling neural layers, integrating state-of-the-art AI into your daily workspace directly.",
    },
  ];

  return (
    <div id="design-philosophy" className="py-24 bg-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100 border-t border-slate-900 overflow-hidden relative">
      {/* Decorative vector background */}
      <div className="absolute inset-x-0 top-0 h-40 bg-[linear-gradient(to_bottom,rgba(6,182,212,0.03),transparent)] pointer-events-none select-none" />
      <div className="absolute -right-20 top-1/3 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none select-none" />

      <div className="max-w-6xl mx-auto space-y-16 relative z-10">
        
        {/* Header Block */}
        <div className="text-center md:text-left max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400 uppercase tracking-widest">
            <Palette className="w-3.5 h-3.5" /> Core Ideology Matrix
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-sans font-medium text-white tracking-tight">
            Design Philosophy: The Intersection of Math, Logic & Beauty
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed leading-[1.6]">
            We refuse to compartmentalize computer science, engineering, and visual design. 
            Great technology is a singular discipline where clean source code compiles into microsecond latency, 
            and elegant typography guides the human operator without hesitation.
          </p>
        </div>

        {/* Visual interactive philosophy showcases */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-4">
          
          {/* Conceptual graphics box */}
          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 rounded-xl border border-slate-850 p-6 flex flex-col justify-between space-y-8 relative overflow-hidden group">
            {/* Grid background */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-30" />
            
            <div className="space-y-4 relative z-10">
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-900/40 px-2.5 py-1 rounded uppercase tracking-widest font-semibold inline-block">
                The Aesthetic Equation
              </span>
              <h3 className="text-xl font-sans font-bold text-white tracking-tight">
                Form Follows Framework
              </h3>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed font-sans">
                Our designs reflect the exact state of the underlying backend. By adhering strictly to structural honesty, we make complex data topologies comprehensible. No simulated logs or superficial fluff — just pure architectural clarity representation.
              </p>
            </div>

            {/* Simulated Canvas Rendering representing design math */}
            <div className="h-44 bg-black/50 rounded-lg border border-slate-800 p-4 font-mono text-[10px] text-slate-500 relative flex flex-col justify-between overflow-hidden relative">
              <div className="flex justify-between items-center text-slate-400 border-b border-slate-900 pb-2">
                <span>[AESTHETIC GRID MATRIX]</span>
                <span className="text-cyan-400 animate-pulse">● CALIBRATED</span>
              </div>
              
              {/* Trigonometric or mathematical representation */}
              <div className="space-y-1 pt-2 flex-1">
                <div>f(x, y) = sin(x / λ) × e^(-t / τ)</div>
                <div className="flex gap-1.5 items-center">
                  <span className="bg-cyan-500/20 text-cyan-400 px-1 rounded">R_GRID</span>
                  <span>= 1.6180339887 (Golden Ratio Splines)</span>
                </div>
                <div className="h-10 w-full bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.15),transparent)] rounded flex items-center justify-center">
                  <div className="w-3/4 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/60 to-transparent relative">
                    <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping" />
                  </div>
                </div>
              </div>

              <div className="text-[9px] text-slate-600 flex justify-between">
                <span>LATENCY_REDUCTION: OPTIMAL</span>
                <span>SYSTEM_SATURATION: 12.4%</span>
              </div>
            </div>
          </div>

          {/* Philosophy points lists */}
          <div className="lg:col-span-7 flex flex-col justify-between gap-6">
            {principles.map((p, idx) => (
              <div
                key={idx}
                className="bg-slate-900/45 border border-slate-850 hover:border-slate-800 p-5 rounded-xl flex items-start gap-4 transition-all hover:bg-slate-900/60"
              >
                <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-850 shrink-0 mt-0.5">
                  {p.icon}
                </div>
                <div className="space-y-1.5">
                  <h4 className="text-sm font-sans font-bold text-slate-100 flex items-center gap-2">
                    {p.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
                    {p.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
}
