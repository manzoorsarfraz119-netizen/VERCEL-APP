import React, { useState } from "react";
import { motion } from "motion/react";
import { ArchitectureBlueprint } from "../types";
import { Server, Cpu, Database, Play, CheckCircle2, AlertTriangle, HelpCircle, Loader2, Copy, Sparkles, RefreshCw, Network } from "lucide-react";

export default function ArchitectStudio() {
  const [projectName, setProjectName] = useState("Distributed Multi-User Chat");
  const [projectType, setProjectType] = useState("Real-time Web API / Websockets");
  const [scaleTarget, setScaleTarget] = useState("100,000 Active Connections (Peak)");
  const [techStack, setTechStack] = useState("Go + Redis + PostgreSQL + Kafka");
  const [description, setDescription] = useState("Requires end-to-end encryption key exchange, message state replication, and sub-10ms pub-sub message latency.");
  
  const [loading, setLoading] = useState(false);
  const [blueprint, setBlueprint] = useState<ArchitectureBlueprint | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<boolean>(false);

  const sampleApps = [
    {
      name: "Global Fintech Ledger",
      type: "Distributed Transaction API",
      scale: "10,000 Transactions/sec with 100% ACID consensus",
      stack: "Java Spring + CockroachDB + Redis Cluster",
      desc: "Double-entry accounting book with distributed raft-based consistency and banking compliance layers."
    },
    {
      name: "Autonomous Vehicle Telemetry",
      type: "Distributed IoT Ingestion Hub",
      scale: "5,000,000 Stream Messages/sec ingestion",
      stack: "Rust + Apache Cassandra + Apache Kafka + gRPC",
      desc: "High-throughput stream processing with sequential disk storage, sliding aggregation windows, and cold file archival."
    },
    {
      name: "Decentralized Video Analytics",
      type: "Serverless Web API + Edge Compute",
      scale: "50,000 Active parallel stream transcodes",
      stack: "Node.js (TypeScript) + DynamoDB + Serverless Workers + Redis",
      desc: "Distributes chunked frame classification tasks, caches local predictions, and exposes GraphQL API gateways."
    }
  ];

  const handleApplySample = (sample: typeof sampleApps[0]) => {
    setProjectName(sample.name);
    setProjectType(sample.type);
    setScaleTarget(sample.scale);
    setTechStack(sample.stack);
    setDescription(sample.desc);
  };

  const compileBlueprint = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setBlueprint(null);

    try {
      const response = await fetch("/api/gemini/architect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectName,
          projectType,
          scaleTarget,
          techStack,
          description
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to formulate blueprint");
      }

      const data = await response.json();
      setBlueprint(data);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Communication failed with architectural node. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const copyDiagram = () => {
    if (blueprint?.diagramText) {
      navigator.clipboard.writeText(blueprint.diagramText);
      setCopiedIndex(true);
      setTimeout(() => setCopiedIndex(false), 2000);
    }
  };

  return (
    <div className="py-20 bg-slate-900 border-t border-b border-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header Block */}
        <div className="space-y-4 text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-400">
            <Cpu className="w-3.5 h-3.5" /> Core Systems Engine
          </div>
          <h2 className="text-3xl md:text-4xl font-sans font-medium text-white tracking-tight">
            Interactive Architecture & Blueprint Studio
          </h2>
          <p className="text-slate-400 max-w-2xl text-sm sm:text-base leading-relaxed">
            Specify technical targets or inject production presets. Our system analyzes dependencies 
            and compiles structured cloud schemas, node layouts, and microservice topologies.
          </p>
        </div>

        {/* Studio Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Work Parameters Card (Inputs) */}
          <div className="lg:col-span-5 bg-slate-950/60 rounded-xl border border-slate-800 p-6 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-900">
              <span className="text-sm font-mono text-slate-300 font-semibold uppercase tracking-wider flex items-center gap-2">
                <Database className="w-4 h-4 text-cyan-500" /> System Specs Input
              </span>
              <span className="text-xs text-slate-500 font-mono">v1.2 // Sandbox</span>
            </div>

            {/* Presets quick select */}
            <div className="space-y-2">
              <span className="text-xs font-mono text-slate-500">Inject Pre-compiled Lab Presets:</span>
              <div className="flex flex-wrap gap-2">
                {sampleApps.map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleApplySample(sample)}
                    className="px-2.5 py-1 text-xs select-none rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 font-sans cursor-pointer text-slate-300 hover:text-white transition-all overflow-hidden text-ellipsis whitespace-nowrap max-w-full"
                  >
                    🚀 {sample.name.split(" ")[0]} Project
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={compileBlueprint} className="space-y-4">
              <div className="space-y-1">
                <label className="block text-xs font-mono text-slate-400">Project Name</label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded font-sans text-sm focus:outline-none focus:border-cyan-500 text-slate-200"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-mono text-slate-400">Deployment Topology / Type</label>
                <input
                  type="text"
                  value={projectType}
                  onChange={(e) => setProjectType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded font-sans text-sm focus:outline-none focus:border-cyan-500 text-slate-200"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-mono text-slate-400">Scaling Load Bound</label>
                  <input
                    type="text"
                    value={scaleTarget}
                    onChange={(e) => setScaleTarget(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded font-sans text-sm focus:outline-none focus:border-cyan-500 text-slate-200"
                    placeholder="e.g. 50k requests/s"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-mono text-slate-400">Node preferences (Stack)</label>
                  <input
                    type="text"
                    value={techStack}
                    onChange={(e) => setTechStack(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded font-sans text-sm focus:outline-none focus:border-cyan-500 text-slate-200"
                    placeholder="e.g. Go + Postgres"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-mono text-slate-400">Additional Engineering Constraints</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded font-sans text-sm focus:outline-none focus:border-cyan-500 text-slate-200 resize-none"
                  placeholder="Identify databases latency bounds, high integrity states or compliance mandates."
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-4 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-semibold font-sans rounded-lg shadow-lg cursor-pointer flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Compiling Specifications...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 text-slate-950 fill-current" />
                    Deploy & Compile Specs
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Blueprint Compiler Console / Output Card */}
          <div className="lg:col-span-7 space-y-4">
            {loading && (
              <div className="min-h-[460px] bg-slate-950/40 rounded-xl border border-dashed border-slate-800 flex flex-col items-center justify-center p-8 text-center space-y-6">
                <Loader2 className="w-12 h-12 text-cyan-500 animate-spin" />
                <div className="space-y-2">
                  <p className="font-mono text-sm text-slate-300">Formulating Distributed Node Topologies...</p>
                  <p className="text-xs text-slate-500 max-w-sm">
                    Connecting to Apex Engineering Node. Applying consensus analysis, picking optimal indexing strategies, and drawing system flow.
                  </p>
                </div>
                <div className="flex gap-2 items-center text-[10px] font-mono bg-slate-900/60 px-3 py-1 border border-slate-800 rounded text-slate-400">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  Gemini System Architect is formulating response
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-6 text-slate-200 space-y-4">
                <div className="flex items-center gap-2.5 text-red-400 font-semibold">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Blueprinting Refused (Error)</span>
                </div>
                <p className="text-xs font-mono text-slate-400 bg-black/40 p-3 rounded">
                  {error}
                </p>
                <p className="text-sm">
                  This state indicates either a remote service latency check failure, or an empty Gemini Key state. Verify keys under Settings tab and try again.
                </p>
              </div>
            )}

            {!blueprint && !loading && !error && (
              <div className="min-h-[460px] bg-slate-950/40 rounded-xl border border-slate-800/80 flex flex-col items-center justify-center p-12 text-center space-y-5">
                <div className="p-4 bg-slate-900 rounded-full border border-slate-800">
                  <Server className="w-8 h-8 text-slate-500" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-base font-sans font-medium text-slate-200">Terminal Idle — Awaiting Specs Compilation</h4>
                  <p className="text-xs text-slate-500 max-w-sm leading-relaxed mx-auto">
                    Complete the configuration form on the left or load one of our specialized preset designs to construct comprehensive computer science reports.
                  </p>
                </div>
                <div className="font-mono text-[11px] text-slate-600 bg-slate-950/80 px-4 py-1.5 rounded border border-slate-900">
                  STATUS: WAITING_FOR_PAYLOAD
                </div>
              </div>
            )}

            {/* Success specifications render */}
            {blueprint && !loading && !error && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="space-y-6"
              >
                {/* Intro summary banner */}
                <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-2">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                    <span className="text-xs font-mono text-cyan-400 tracking-wider">SYSTEM BLUEPRINT // COMPILED</span>
                    <span className="inline-flex px-1.5 py-0.5 text-[10px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded uppercase font-mono tracking-widest font-semibold">
                      READY FOR LABS
                    </span>
                  </div>
                  <h3 className="text-lg font-sans text-slate-100 font-semibold leading-relaxed">
                    Overview of Engineering Decision:
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed leading-normal font-sans">
                    {blueprint.introduction}
                  </p>
                </div>

                {/* Microservice Flow / Network Diagram Header */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
                  <div className="bg-slate-900/80 px-4 py-2.5 border-b border-slate-850 flex justify-between items-center text-xs font-mono">
                    <span className="text-slate-300 flex items-center gap-2">
                      <Network className="w-4 h-4 text-cyan-400" /> Architecture Topology Diagram
                    </span>
                    <button
                      onClick={copyDiagram}
                      className="px-2 py-1 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-[10px] text-slate-400 rounded flex items-center gap-1 cursor-pointer transition-all"
                    >
                      {copiedIndex ? "Copied" : "Copy ASCII"}
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto text-[11px] md:text-xs font-mono text-cyan-300 bg-black/60 leading-relaxed whitespace-pre font-medium">
                    {blueprint.diagramText}
                  </pre>
                </div>

                {/* Database & Caching Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Database selection */}
                  <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase tracking-wider">
                      <Database className="w-4 h-4" /> Recommended Database
                    </div>
                    <div className="text-sm font-semibold text-slate-100 bg-slate-900/80 p-2 rounded border border-slate-850 font-sans">
                      {blueprint.databaseChoice.recommended}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {blueprint.databaseChoice.justification}
                    </p>
                  </div>

                  {/* Caching layers */}
                  <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono text-indigo-400 uppercase tracking-wider">
                        <Server className="w-4 h-4" /> Caching & Session Engine
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed mt-2 font-sans">
                        {blueprint.cachingLayer}
                      </p>
                    </div>
                    <div className="pt-2 text-[10px] font-mono text-slate-500">
                      STRATEGY: LATENCY-ORIENTED PRE-FETCH
                    </div>
                  </div>
                </div>

                {/* Scalability card */}
                <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-2">
                  <div className="text-xs font-mono text-purple-400 uppercase tracking-wider">
                    ⚡ Elastic Scaling & Failover Policy
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed">
                    {blueprint.scalingStratey}
                  </p>
                </div>

                {/* Detailed Components Table */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
                  <div className="bg-slate-900/60 p-3.5 border-b border-slate-850 text-xs font-mono text-slate-300 font-semibold uppercase">
                    Components Ledger
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs font-sans">
                      <thead>
                        <tr className="bg-slate-900 text-slate-400 font-mono text-[10px]">
                          <th className="p-3">Component Node</th>
                          <th className="p-3">Primary Tech</th>
                          <th className="p-3">Functional Service Role</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900">
                        {blueprint.componentsTable.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-900/20 text-slate-300">
                            <td className="p-3 font-mono font-semibold text-cyan-400 text-[11px]">{item.component}</td>
                            <td className="p-3 font-mono text-[11px] text-slate-200">{item.technology}</td>
                            <td className="p-3 text-slate-400 text-xs">{item.role}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Engineering Risk Warning Checklist */}
                <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-3">
                  <div className="flex items-center gap-2 text-xs font-mono text-amber-500 uppercase tracking-wider">
                    <AlertTriangle className="w-4 h-4" /> Key Engineering Risk Factors & Mitigations
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300 font-sans leading-relaxed">
                    {blueprint.riskAnalysis.map((risk, idx) => (
                      <li key={idx} className="flex items-start gap-2 bg-slate-900/60 border border-slate-850 p-2.5 rounded text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>

              </motion.div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}
