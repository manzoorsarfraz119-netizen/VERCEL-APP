import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Briefcase, ArrowRight, ShieldCheck, Database, Zap, Sparkles, AlertCircle, Cpu } from "lucide-react";

interface Project {
  id: string;
  title: string;
  category: string;
  categoryType: "cs" | "se" | "design";
  shortDesc: string;
  problem: string;
  solution: string;
  technologies: string[];
  metrics: string;
}

export default function PortfolioSection() {
  const [activeTab, setActiveTab] = useState<string>("p1");

  const projects: Project[] = [
    {
      id: "p1",
      title: "Veridian Ledger Core",
      category: "Distributed Consistency Engine",
      categoryType: "cs",
      shortDesc: "Double-entry financial ledger utilizing parallelized Byzantine-fault tolerant raft consensus protocols.",
      problem: "Traditional relational databases experienced high lock-contention, blocking critical writes across overseas ledger entities. Peak load processing would delay validation sequences to over 3.2 seconds.",
      solution: "Engineered a custom double-entry book with Raft-consensus multi-leader replication, reducing the verification window to sub-25ms. Enriched the ledger with a beautiful node dashboard representing visual peer-to-peer state channels.",
      technologies: ["Go", "CockroachDB", "WebAssembly", "Tailwind CSS"],
      metrics: "99.998% ACID Sync Integrity under 50k RPS"
    },
    {
      id: "p2",
      title: "Helios Telemetry Mesh",
      category: "IoT Ingestion Pipeline",
      categoryType: "se",
      shortDesc: "Architecting ingestion and routing pipes for autonomous vehicle sensor event streams.",
      problem: "Vehicles streaming gigabytes of visual diagnostic files crashed the central message queues. Standard operators lacked visual tools to inspect geographic routing paths intuitively.",
      solution: "Constructed an append-only sequential storage pipeline. Processed streams are dynamically summarized and mapped onto an optimized vector canvas that maps coordinate points seamlessly.",
      technologies: ["Rust", "Apache Kafka", "ScyllaDB", "WebGL Cores"],
      metrics: "5.4M Stream events ingestion / sec stable"
    },
    {
      id: "p3",
      title: "Cortex Diagnostic Canvas",
      category: "User-Centered Healthcare UI",
      categoryType: "design",
      shortDesc: "Simplifying neural segmentation results to eliminate clinical diagnostic fatigue.",
      problem: "Radiologists faced massive, tabular raw neural outputs from AI models, causing cognitive distress, misread telemetry, and visual fatigue during long shifts.",
      solution: "Translated complex convolutional weight matrices into clean, interactive layered overlays. Designed custom slide comparing vectors and focus zones wrapped in high-contrast cosmic dark frames.",
      technologies: ["React", "TypeScript", "motion/react", "Docker"],
      metrics: "42% Reduction in clinical analysis review times"
    },
    {
      id: "p4",
      title: "Prism Global Edge Cache",
      category: "Global Distributed Routing",
      categoryType: "cs",
      shortDesc: "High-integrity multi-region edge mesh routing static files dynamically around failover nodes.",
      problem: "Traditional cloud load balancers dropped up to 14% of transactions during regional server failures because of slow, static configuration changes.",
      solution: "Implemented an edge consistent hashing ring algorithm that maps cache addresses dynamically to nearby operational nodes clockwise. Added a live monitoring grid for diagnostic engineers.",
      technologies: ["Node.js", "Consistent Hashing Ring", "Docker", "Tailwind"],
      metrics: "Sub-5ms network routing with zero mapping splits"
    }
  ];

  const currentProject = projects.find((p) => p.id === activeTab) || projects[0];

  return (
    <div id="portfolio" className="py-24 bg-slate-900 border-t border-b border-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100 relative">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-400 uppercase tracking-widest">
              <Briefcase className="w-3.5 h-3.5" /> Case Studies Ledger
            </div>
            <h2 className="text-3xl md:text-4xl font-sans font-medium text-white tracking-tight">
              Selected Software & Systems Portfolios
            </h2>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              Explore past deep engineering assignments where we solved rigorous software engineering, theoretical computer science, and user ergonomics problems simultaneously.
            </p>
          </div>

          <div className="flex gap-2 items-center font-mono text-[10px] text-slate-500 bg-slate-950/80 px-4 py-2 border border-slate-850 rounded">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>TOTAL VERIFIED LABS PORTFOLIOS: 4</span>
          </div>
        </div>

        {/* Dynamic Project Tabs Grid Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Tabs Column on Left (4 cols) */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest pl-1 font-semibold block">
              Toggle Past Engineering Reports:
            </span>
            {projects.map((proj) => (
              <button
                key={proj.id}
                onClick={() => setActiveTab(proj.id)}
                className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col gap-1.5 select-none ${
                  activeTab === proj.id
                    ? "bg-slate-950 border-cyan-500/60 shadow-lg shadow-cyan-500/5 text-white"
                    : "bg-slate-950/45 border-slate-850 hover:border-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                <div className="flex items-center justify-between">
                  {/* Category Pill Tag */}
                  <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border font-semibold ${
                    proj.categoryType === "cs" 
                      ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                      : proj.categoryType === "se"
                      ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                      : "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                  }`}>
                    {proj.categoryType === "cs" ? "Comp Sci" : proj.categoryType === "se" ? "Software Eng" : "System Design"}
                  </span>
                  <span className="text-[10px] font-mono text-slate-500 font-medium">0{proj.id.replace("p", "")} // LAB</span>
                </div>
                <h4 className="font-sans font-bold text-sm tracking-tight text-slate-100">{proj.title}</h4>
                <p className="text-slate-400 text-xs font-sans line-clamp-1 truncate block">{proj.shortDesc}</p>
              </button>
            ))}
          </div>

          {/* Detailed Selected Project Report Panel (8 cols) */}
          <div className="lg:col-span-8 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentProject.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.3 }}
                className="p-6 sm:p-8 space-y-6"
              >
                {/* Header info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-900">
                  <div className="space-y-1">
                    <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest block font-bold">
                      {currentProject.category}
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-sans font-medium text-white tracking-tight">
                      {currentProject.title}
                    </h3>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl flex flex-col items-center justify-center shrink-0">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">SLO Achievement</span>
                    <span className="text-xs font-mono text-cyan-400 font-bold">{currentProject.metrics}</span>
                  </div>
                </div>

                {/* Case Study Details blocks of Problem & Solution */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  <div className="space-y-3 bg-slate-900/40 p-5 rounded-xl border border-slate-850/50">
                    <h4 className="text-xs font-mono text-amber-500 flex items-center gap-1.5 uppercase tracking-widest font-bold">
                      <AlertCircle className="w-4 h-4 shrink-0" /> The Problem State
                    </h4>
                    <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-sans">
                      {currentProject.problem}
                    </p>
                  </div>

                  <div className="space-y-3 bg-slate-900/40 p-5 rounded-xl border border-slate-850/50">
                    <h4 className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 uppercase tracking-widest font-bold">
                      <ShieldCheck className="w-4 h-4 shrink-0" /> Crafted Engineering Solution
                    </h4>
                    <p className="text-slate-300 text-xs sm:text-sm leading-relaxed font-sans">
                      {currentProject.solution}
                    </p>
                  </div>
                </div>

                {/* Tech Badges Block */}
                <div className="space-y-3 bg-slate-900/10 p-4 rounded-xl border border-slate-900 flex flex-col justify-between sm:flex-row sm:items-center gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-semibold block">Verified Stack Deployment</span>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {currentProject.technologies.map((t, i) => (
                        <span key={i} className="px-2.5 py-1 bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-mono text-slate-300 rounded transition-colors select-none">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-semibold mb-1">Architecture Node Deployment</span>
                    <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/20 border border-cyan-900/40 py-1 px-3 rounded inline-block">
                      VERIFIED_SECURE_REPL
                    </span>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </div>
  );
}
