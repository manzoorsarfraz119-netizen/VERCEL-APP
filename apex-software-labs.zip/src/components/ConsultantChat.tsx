import React, { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";
import { ChatMessage } from "../types";
import { Send, Terminal, Loader2, Sparkles, AlertCircle, Bot, MessageSquareCode, Trash2 } from "lucide-react";

export default function ConsultantChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "model",
      text: "Developer Node Online. I am the Principal Systems Engineer here at SHEHROZ SOFT. Ask me about system topology, databases tradeoffs, consistent hashing, or distributed ledger consensus."
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [tempError, setTempError] = useState<string | null>(null);
  
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  // Auto scroll to latest chats
  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const presetQueries = [
    {
      label: "SQL vs NoSQL scaling",
      query: "Explain the architectural tradeoffs of horizontal write-scaling in SQL (e.g. Spanner/CockroachDB vs Cockroach Multi-Region) versus NoSQL (Cassandra/DynamoDB masterless partitioning)."
    },
    {
      label: "Kafka vs RabbitMQ",
      query: "Analyze Kafka append-only logs vs RabbitMQ AMQP routing topologies. When should we prefer sequential storage over high dynamic routing?"
    },
    {
      label: "Solve Thundering Herd",
      query: "What is a 'Thundering Herd' caching problem under peak traffic? Show a dynamic fallback code snippet or policy using lock leases to solve it."
    },
    {
      label: "Distributed Transactions (Saga)",
      query: "Explain how to coordinate high-integrity states across microservices using the Saga Pattern (Orchestration vs Choreography) without blocking databases."
    }
  ];

  const handleSendMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText || inputMessage;
    if (!textToSend.trim() || loading) return;

    // Reset error
    setTempError(null);

    // Save user chat state
    const userMessage: ChatMessage = { role: "user", text: textToSend };
    setMessages((prev) => [...prev, userMessage]);
    
    // Clear input
    if (!customText) setInputMessage("");
    setLoading(true);

    try {
      // Collect structured chat history to send for context
      const chatHistory = messages.map((m) => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: textToSend, chatHistory }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to communicate with Apex Advisor Node");
      }

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "model", text: data.text || "No response compiled." }
      ]);
    } catch (err: any) {
      console.error(err);
      setTempError(err?.message || "Advisor node did not reply. Verify key configs.");
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        role: "model",
        text: "Developer Node Online. Ask me anything about SHEHROZ SOFT's technical suite or distributed software systems."
      }
    ]);
    setTempError(null);
  };

  return (
    <div className="py-20 bg-slate-900 border-b border-slate-950 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-100">
      <div className="max-w-5xl mx-auto space-y-10">
        
        {/* Header Block */}
        <div className="space-y-4 text-center md:text-left flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-400">
              <Bot className="w-3.5 h-3.5" /> SHEHROZ SOFT Node
            </div>
            <h2 className="text-3xl md:text-4xl font-sans font-medium text-white tracking-tight">
              AI Systems Adviser & Consultant // SHEHROZ SOFT
            </h2>
            <p className="text-slate-400 max-w-xl text-sm leading-relaxed">
              Consult with SHEHROZ SOFT's AI agent. Ask deep development questions about multi-region consensus, CAP theorem trade-offs, high-throughput pipelines, and elegant user-centric design layouts.
            </p>
          </div>

          <button
            onClick={handleClearChat}
            className="px-3.5 py-1.5 self-start md:self-auto bg-slate-950 border border-slate-800 hover:bg-slate-850 hover:border-slate-700 text-xs font-mono text-slate-400 hover:text-red-400 rounded flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" /> Clear Logs
          </button>
        </div>

        {/* Consulting Interactive Terminal */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Quick Preset Prompts Left Side (4 columns) */}
          <div className="lg:col-span-4 bg-slate-950 rounded-xl border border-slate-800 p-5 space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-xs font-mono text-slate-500 uppercase tracking-wider block">
                Lab Consult Presets
              </span>
              <p className="text-slate-400 text-xs leading-relaxed font-sans">
                Select one of our research topics to receive instant detailed comparative writeups from the Principal Architect node.
              </p>
              
              <div className="space-y-2 pt-2">
                {presetQueries.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={(e) => handleSendMessage(e, item.query)}
                    disabled={loading}
                    className="w-full text-left p-3 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition-all rounded-lg text-xs font-semibold font-sans text-cyan-400 hover:text-cyan-300 block cursor-pointer select-none disabled:opacity-50"
                  >
                    🚀 {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-900 text-[10px] font-mono text-slate-500 flex items-center gap-1.5">
              <MessageSquareCode className="w-4 h-4 text-cyan-500" />
              <span>SHEHROZ SOFT STATUS: ONLINE</span>
            </div>
          </div>

          {/* Interactive terminal Chat Logs (8 columns) */}
          <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 flex flex-col h-[480px]">
            
            {/* Terminal Top tab bar */}
            <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-850 flex justify-between items-center text-xs font-mono">
              <span className="text-slate-300 flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" /> developer-systems-shell.sh
              </span>
              <span className="inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            </div>

            {/* Chats loop block */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 leading-relaxed font-sans text-sm scrollbar-thin">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg p-3.5 ${
                      m.role === "user"
                        ? "bg-cyan-500 text-slate-950 font-medium"
                        : "bg-slate-905 border border-slate-850 text-slate-200"
                    }`}
                  >
                    {/* Role header inside message bubble */}
                    <div className="flex items-center gap-1.5 pb-1 text-[10px] uppercase font-mono tracking-widest leading-none select-none text-slate-500 text-slate-505/60 font-semibold mb-1">
                      <span>{m.role === "user" ? "Client Workspace" : "SHEHROZ SOFT Architect"}</span>
                    </div>

                    {/* Chat Text */}
                    <p className={`whitespace-pre-wrap ${m.role === "model" ? "font-sans leading-relaxed text-xs sm:text-sm text-slate-300" : "text-slate-950 text-xs sm:text-sm font-sans"}`}>
                      {m.text}
                    </p>
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-2 max-w-[80%]">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-slate-500 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                      Evaluating System Constraints...
                    </span>
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-3.5 h-3.5 text-slate-400 animate-spin" />
                      <span className="text-xs text-slate-500 font-mono">Writing specifications report...</span>
                    </div>
                  </div>
                </div>
              )}

              {tempError && (
                <div className="bg-red-500/10 border border-red-500/20 rounded p-3 text-red-400 text-xs flex gap-2 items-start font-mono">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">CONNECTION_TIMEOUT_ERROR</p>
                    <p className="text-[10px] text-slate-500 mt-1">{tempError}</p>
                  </div>
                </div>
              )}

              <div ref={endOfMessagesRef} />
            </div>

            {/* Chat Input panel bottom */}
            <div className="p-3 border-t border-slate-900 bg-slate-900/40">
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask a technical or computer science question..."
                  className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-850 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500 font-sans"
                  disabled={loading}
                />
                <button
                  type="submit"
                  disabled={loading || !inputMessage.trim()}
                  className="px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg font-sans text-xs sm:text-sm font-semibold flex items-center gap-1.5 cursor-pointer select-none transition-all active:scale-[0.98] disabled:opacity-40"
                >
                  <Send className="w-3.5 h-3.5" />
                  Send
                </button>
              </form>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
