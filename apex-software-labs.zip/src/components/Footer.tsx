import { Code2, Github, Globe, Shield } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 border-t border-slate-900 py-12 px-4 sm:px-6 md:px-12 lg:px-24 text-slate-500 font-sans text-xs">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        
        {/* Left trademark branding */}
        <div className="flex items-center gap-2.5">
          <div className="p-1 px-2 rounded bg-slate-900 border border-slate-800 text-cyan-400 font-mono text-[10px]">
            SHEHROZ SOFT
          </div>
          <span>&copy; {currentYear} SHEHROZ SOFT. All engineering systems active.</span>
        </div>

        {/* Center: simple links */}
        <div className="flex gap-4 text-slate-400 font-mono text-[10px]">
          <span className="hover:text-cyan-400 cursor-default">DISTRIBUTED CONSENSUS</span>
          <span className="text-slate-800">|</span>
          <span className="hover:text-cyan-400 cursor-default">FORMAL VERIFICATION</span>
          <span className="text-slate-800">|</span>
          <span className="hover:text-cyan-400 cursor-default">COMPILER LABS</span>
        </div>

        {/* Right status feedback */}
        <div className="flex items-center gap-2.5 font-mono text-[10px] text-slate-500 bg-slate-900/40 px-3 py-1.5 rounded border border-slate-900">
          <Shield className="w-3.5 h-3.5 text-cyan-400" />
          <span>VITE-COMPOSER // STABLE</span>
        </div>

      </div>
    </footer>
  );
}
