import { motion } from "motion/react";
import { Terminal, Cpu, Database, Network, ArrowDown } from "lucide-react";

export default function HeroSection({ scrollToSection }: { scrollToSection: (id: string) => void }) {
  return (
    <div className="relative min-h-[85vh] flex flex-col justify-center items-center overflow-hidden bg-slate-950 px-6 sm:px-12 md:px-20 text-slate-100">
      {/* Background grid canvas accent */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] opacity-30 select-none pointer-events-none" />

      {/* Decorative floating system lines */}
      <div className="absolute top-1/4 left-1/10 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-4xl text-center space-y-8 flex flex-col items-center">
        {/* Humble and pristine status flag */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400 select-none tracking-widest uppercase"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
          </span>
          Computer Science & Systems Lab
        </motion.div>

        {/* Masterful Display Typography */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-4xl sm:text-6xl md:text-7xl font-sans font-medium tracking-tight text-white leading-[1.1] max-w-4xl"
        >
          Engineering the Next Generation of{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 font-semibold">
            Distributed Software
          </span>
        </motion.h1>

        {/* Cohesive Subtitle explaining what we do */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.25 }}
          className="text-slate-400 text-base sm:text-xl max-w-2xl font-sans leading-relaxed tracking-wide"
        >
          SHEHROZ SOFT, in partnership with Apex Labs, is a research-driven computer science & software engineering consultancy. We formulate multi-master database strategies, analyze high-load consistent hashing channels, and build elegant computational interfaces.
        </motion.p>

        {/* Core pillar buttons */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
        >
          <button
            onClick={() => scrollToSection("architect-studio")}
            className="w-full sm:w-auto px-8 py-3.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-medium rounded-lg shadow-lg hover:shadow-cyan-500/10 cursor-pointer transition-all active:scale-[0.98] border border-transparent font-sans flex items-center justify-center gap-2"
          >
            <Cpu className="w-4 h-4" />
            Architect Blueprint Studio
          </button>
          <button
            onClick={() => scrollToSection("algorithm-playground")}
            className="w-full sm:w-auto px-8 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-200 font-medium rounded-lg cursor-pointer transition-all active:scale-[0.98] border border-slate-800 font-sans flex items-center justify-center gap-2"
          >
            <Network className="w-4 h-4 text-cyan-500" />
            CS Ring Visualizer
          </button>
        </motion.div>

        {/* Mini Technical Pillars Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-3xl mt-6 border-t border-slate-900"
        >
          <div className="flex flex-col items-center p-3 rounded-lg bg-slate-900/40 border border-slate-900/60">
            <Network className="w-5 h-5 text-cyan-400 mb-2" />
            <span className="text-xs font-mono text-slate-300">Distributed Mesh</span>
          </div>
          <div className="flex flex-col items-center p-3 rounded-lg bg-slate-900/40 border border-slate-900/60">
            <Cpu className="w-5 h-5 text-blue-400 mb-2" />
            <span className="text-xs font-mono text-slate-300">System Compiler</span>
          </div>
          <div className="flex flex-col items-center p-3 rounded-lg bg-slate-900/40 border border-slate-900/60">
            <Database className="w-5 h-5 text-indigo-400 mb-2" />
            <span className="text-xs font-mono text-slate-300">Consistent Storage</span>
          </div>
          <div className="flex flex-col items-center p-3 rounded-lg bg-slate-900/40 border border-slate-900/60">
            <Terminal className="w-5 h-5 text-emerald-400 mb-2" />
            <span className="text-xs font-mono text-slate-300">Strict Latency</span>
          </div>
        </motion.div>

        {/* Scroll action prompt */}
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="pt-8 text-xs font-mono text-slate-500 flex flex-col items-center gap-1 select-none"
        >
          Explore Live Architectural Tools
          <ArrowDown className="w-4 h-4 text-cyan-500/60 mt-1" />
        </motion.div>
      </div>
    </div>
  );
}
