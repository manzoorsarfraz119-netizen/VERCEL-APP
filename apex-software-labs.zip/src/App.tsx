import { motion } from "motion/react";
import HeroSection from "./components/HeroSection";
import ArchitectStudio from "./components/ArchitectStudio";
import ConsistentHashingRing from "./components/ConsistentHashingRing";
import ConsultantChat from "./components/ConsultantChat";
import CorporateDetails from "./components/CorporateDetails";
import DesignPhilosophy from "./components/DesignPhilosophy";
import PortfolioSection from "./components/PortfolioSection";
import Footer from "./components/Footer";
import { Terminal, Cpu, Network, Bot, Award, Menu, X, Palette, Briefcase } from "lucide-react";
import { useState } from "react";

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Smooth scroll handler
  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Top Header Navigation bar */}
      <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-900 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo Brand Brand */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
            <div className="p-1 px-2.5 rounded bg-cyan-500/15 border border-cyan-500/25 text-cyan-400 font-mono text-xs font-bold tracking-widest uppercase">
              Shehroz
            </div>
            <span className="text-sm font-sans font-medium hover:text-cyan-400 transition-colors tracking-wide text-white">
              Soft Systems
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-6 text-[11px] font-mono uppercase tracking-wider text-slate-400">
            <button
              onClick={() => scrollToSection("core-divisions")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Award className="w-3.5 h-3.5" /> Services
            </button>
            <button
              onClick={() => scrollToSection("design-philosophy")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Palette className="w-3.5 h-3.5" /> Philosophy
            </button>
            <button
              onClick={() => scrollToSection("portfolio")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Briefcase className="w-3.5 h-3.5" /> Portfolios
            </button>
            <button
              onClick={() => scrollToSection("architect-studio")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Cpu className="w-3.5 h-3.5" /> Systems Builder
            </button>
            <button
              onClick={() => scrollToSection("algorithm-playground")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Network className="w-3.5 h-3.5" /> Algorithmic Ring
            </button>
            <button
              onClick={() => scrollToSection("ai-consultant")}
              className="hover:text-cyan-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
            >
              <Bot className="w-3.5 h-3.5" /> Systems Advisor
            </button>
          </nav>

          {/* Call to action contact button */}
          <div className="hidden md:flex items-center gap-2.5">
            <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
              SYSTEMS ACTIVE
            </span>
          </div>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden text-slate-400 hover:text-white cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

        </div>

        {/* Mobile menu overlay */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="xl:hidden mt-4 pt-4 border-t border-slate-900 flex flex-col gap-4 text-xs font-mono text-slate-400 uppercase tracking-widest px-2"
          >
            <button
              onClick={() => scrollToSection("core-divisions")}
              className="text-left py-2 hover:text-cyan-400 border-b border-slate-900/40"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection("design-philosophy")}
              className="text-left py-2 hover:text-cyan-400 border-b border-slate-900/40"
            >
              Philosophy
            </button>
            <button
              onClick={() => scrollToSection("portfolio")}
              className="text-left py-2 hover:text-cyan-400 border-b border-slate-900/40"
            >
              Portfolios
            </button>
            <button
              onClick={() => scrollToSection("architect-studio")}
              className="text-left py-2 hover:text-cyan-400 border-b border-slate-900/40"
            >
              Systems Builder
            </button>
            <button
              onClick={() => scrollToSection("algorithm-playground")}
              className="text-left py-2 hover:text-cyan-400 border-b border-slate-900/40"
            >
              Algorithmic Ring
            </button>
            <button
              onClick={() => scrollToSection("ai-consultant")}
              className="text-left py-2 hover:text-cyan-400"
            >
              Systems Advisor
            </button>
          </motion.div>
        )}
      </header>

      {/* Main Pages section workflow */}
      <main className="flex-1">
        
        {/* Dynamic Atmospheric Intro */}
        <HeroSection scrollToSection={scrollToSection} />

        {/* Section: Technical divisions (Core Services detailed with examples) */}
        <div id="core-divisions">
          <CorporateDetails />
        </div>

        {/* Section: Design Philosophy linking math & visuals */}
        <DesignPhilosophy />

        {/* Section: Projects Portfolio Showcase Case Studies */}
        <PortfolioSection />

        {/* Section: Systems Architect Playground with real server-side AI compilation */}
        <div id="architect-studio">
          <PageBreakHeader text="Interactive Sandbox Suite" badge="COMPILED MODULES" />
          <ArchitectStudio />
        </div>

        {/* Section: Core algorithmic simulator of Consistent hashing circle rings */}
        <ConsistentHashingRing />

        {/* Section: Chat interaction panel */}
        <div id="ai-consultant">
          <ConsultantChat />
        </div>

      </main>

      {/* Standard brand footer */}
      <Footer />
      
    </div>
  );
}

// Visual layout helper to separate sections cleanly
function PageBreakHeader({ text, badge }: { text: string; badge: string }) {
  return (
    <div className="bg-slate-950 py-10 text-center relative border-t border-slate-900 select-none">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-900/5 to-transparent pointer-events-none" />
      <div className="max-w-2xl mx-auto space-y-1 relative z-10">
        <span className="text-[10px] font-mono text-cyan-400/70 border border-cyan-950 px-2 py-0.5 rounded font-bold uppercase tracking-widest bg-cyan-950/10">
          {badge}
        </span>
        <h3 className="text-slate-500 font-mono text-xs tracking-widest uppercase pt-2">
          {text}
        </h3>
      </div>
    </div>
  );
}
