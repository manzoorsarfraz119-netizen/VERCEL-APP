import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy reference to GoogleGenAI client
let aiClient: GoogleGenAI | null = null;

function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("Waring: GEMINI_API_KEY is not defined in environment variables.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "MOCK_KEY_IF_ABSENT",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. Technical Advisor Q&A endpoint
app.post("/api/gemini/advisor", async (req, res) => {
  try {
    const { message, chatHistory } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Missing required parameter: message" });
    }

    const ai = getGeminiClient();
    
    // Construct rich system instructions for a high-end Software Architect
    const systemInstruction = 
      "You are the Principal Systems Architect and Distinguished Engineer of SHEHROZ SOFT, a premier high-end computer science, software engineering, and intelligent systems design company in collaboration with Apex Software Labs. " +
      "You represent a level of design competence and software execution that is elite, modern, precise, and highly practical. " +
      "Provide technical explanations that are concise, mathematically sound, architectural, and directly helpful. " +
      "We fuse strict engineering with gorgeous functional aesthetics. " +
      "Avoid empty marketing fluff. Focus on database choices, scaling strategies, network protocols, caching layers, and clean code principles. " +
      "Format your response beautifully with Markdown headers, bullet points, and codeblocks where appropriate.";

    const contents = [];
    if (chatHistory && Array.isArray(chatHistory)) {
      for (const turn of chatHistory) {
         contents.push({
           role: turn.role,
           parts: [{ text: turn.text }]
         });
      }
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Advisor API Error:", error);
    res.status(500).json({ error: error?.message || "Internal server error" });
  }
});

// 2. Custom System Architecture Diagram & Technical Specs Generator endpoint
app.post("/api/gemini/architect", async (req, res) => {
  try {
    const { projectName, projectType, scaleTarget, techStack, description } = req.body;
    
    if (!projectName || !projectType) {
      return res.status(400).json({ error: "projectName and projectType are required" });
    }

    const ai = getGeminiClient();

    const prompt = `Design a comprehensive system architecture for the following project:
- Name: ${projectName}
- Type: ${projectType} (e.g. Real-time SaaS, Distributed Data Pipeline, Microservices, Mobile Hub, Web3)
- Scaling Target: ${scaleTarget || "Standard: 10k users/day"}
- Technology Stack Preference: ${techStack || "Modern Cloud Native (Any)"}
- Functional Requirements: ${description || "General Software Engineering Solutions"}

Generate a highly structured layout returned in JSON conforming to the requested schema. Provide deep engineering decisions, a text-based ASCII/Mermaid pseudo-diagram representation, potential bottleneck warnings, and concrete steps to build.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a professional computer science research and software engineering compiler. Return architectural specs strictly in structured JSON matching the database schema.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            introduction: { type: Type.STRING, description: "Overview of the architectural decisions." },
            diagramText: { type: Type.STRING, description: "An elegant ASCII art flow diagram representing client -> load balancer -> web servers -> caching -> database." },
            databaseChoice: {
              type: Type.OBJECT,
              properties: {
                recommended: { type: Type.STRING },
                justification: { type: Type.STRING }
              },
              required: ["recommended", "justification"]
            },
            cachingLayer: { type: Type.STRING, description: "Strategy for caching and edge delivery." },
            scalingStratey: { type: Type.STRING, description: "Horizontal/Vertical scaling and failover strategy details." },
            componentsTable: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  component: { type: Type.STRING },
                  technology: { type: Type.STRING },
                  role: { type: Type.STRING }
                },
                required: ["component", "technology", "role"]
              }
            },
            riskAnalysis: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3 key engineering risks (e.g., race conditions, storage bottlenecks) and how to mitigate them."
            }
          },
          required: ["introduction", "diagramText", "databaseChoice", "cachingLayer", "scalingStratey", "componentsTable", "riskAnalysis"]
        }
      }
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    console.error("Gemini Architect API Error:", error);
    res.status(500).json({ error: error?.message || "Internal server error" });
  }
});

// Serve frontend build and handle routing
async function initServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in DEVELOPMENT mode with Vite Middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in PRODUCTION mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Apex Software Labs Server] running with Express on http://localhost:${PORT}`);
  });
}

initServer().catch((err) => {
  console.error("Failed to initialize server:", err);
});
